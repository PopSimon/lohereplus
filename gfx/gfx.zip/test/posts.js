test_posts = {
    "1234" : {
        "id" : 1234,
        "poster" : "Citad Ella :(",
        "date" : "2011-09-01T19:15+01:00",
        "image" : {
            "source" : "images/user/fullimages/cica.jpeg",
            "thumbnail" : "images/user/thumbnails/thumb_cica.jpeg",
            "resolution" : {
                "width" : 242,
                "height" : 209
            },
            "size" : 6.82
        },
        "text" : 'Sziasztok, egy <span class="KOCSOG" style="color: #a1c232; background-color: #3fccb3;">KÖCSÖG</span> vagyok, kérlek erőszakoljátok meg az arcom.'
    },
    "1235" : {
        "id" : 1235,
        "type" : "sage",
        "poster" : "Magyar Csanád",
        "date" : "2011-09-01T19:20+01:00",
        "image" : {
            "source" : "images/user/fullimages/zsalyas_bill_gates.jpg",
            "thumbnail" : "images/user/thumbnails/thumb_zsalyas_bill_gates.jpg",
            "resolution" : {
                "width" : 480,
                "height" : 360
            },
            "size" : 50.8
        },
        "text" : '<a href="#1234" class="reply" rel="nofollow">>>1234</a> Zsálya'
    },
    "1236" : {
        "id" : 1236,
        "type" : "echelon",
        "poster" : "Molnár F. Árpád",
        "date" : "2011-09-01T19:25+01:00",
        "image" : {
            "source" : "images/user/fullimages/molnar_f_arpad_ns1.JPG",
            "thumbnail" : "images/user/thumbnails/thumb_molnar_f_arpad_ns1.JPG",
            "resolution" : {
                "width" : 480,
                "height" : 360
            },
            "size" : 50.8
        },
        "text" : '<a href="#1235" class="reply" rel="nofollow">>>1235</a> Infantilis és öngyilkos programozottság és non stop folyamatos implantálás okán nem tehetsz mást. Kizáratlak a rendszerből. Többet nem jöhetsz közénk. Tetteid nem fognak segíteni. Ez az életprogramod. Nincs többé kiút. Bemutatja magát a HÍRHÁTTÉR: mindazoknak, akik rosszul közeledtek: http://www.youtube.com/watch?v­=l5I1q4KhKNU'
    },
    "1237" : {
        "id" : 1237,
        "poster" : "Citad Ella :(",
        "date" : "2011-09-01T19:15+01:00",
        "image" : {
            "source" : "images/user/fullimages/naty.jpg",
            "thumbnail" : "images/user/thumbnails/thumb_naty.jpg",
            "resolution" : {
                "width" : 707,
                "height" : 1000
            },
            "size" : 590
        },
        "text" : 'Itt egy nagy kép, hátha szar az oldal' +
        'Ja, meg egy link <a href="#1236" class="reply" rel="nofollow">>>1236</a>'
    },
    "1238" : {
        "id" : 1238,
        "poster" : "Citad Ella :(",
        "date" : "2011-09-01T19:15+01:00",
        "image" : {
            "source" : "images/user/fullimages/natyonnaty.jpg",
            "thumbnail" : "images/user/thumbnails/thumb_natyonnaty.jpg",
            "resolution" : {
                "width" : 5775,
                "height" : 3541
            },
            "size" : "sok :C"
        },
        "text" : 'Itt egy még nagyobb kép, lásd előző' + 
        'Ja, meg egy link <a href="#1237" class="reply" rel="nofollow">>>1237</a>'
    }
};
